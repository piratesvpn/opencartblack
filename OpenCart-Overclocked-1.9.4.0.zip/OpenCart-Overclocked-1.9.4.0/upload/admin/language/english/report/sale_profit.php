<?php
// Heading
$_['heading_title']     = 'Profits Report';

// Text
$_['text_total']        = 'Total';
$_['text_all_status']   = 'All Statuses';

// Column
$_['column_date_start'] = 'Date Start';
$_['column_date_end']   = 'Date End';
$_['column_year']       = 'Year';
$_['column_month']      = 'Month';
$_['column_price']      = 'Sales';
$_['column_cost']       = 'Cost';
$_['column_profit']     = 'Profit';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Date Start:';
$_['entry_date_end']    = 'Date End:';
$_['entry_status']      = 'Order Status:';
