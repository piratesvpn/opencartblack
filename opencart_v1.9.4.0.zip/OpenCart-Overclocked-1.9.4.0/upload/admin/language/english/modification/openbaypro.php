<?php
// Heading
$_['heading_title']     = 'OpenBay Pro';

// Text
$_['text_modification'] = 'Modifications';
$_['text_installed']    = 'OpenBay Pro is now installed. It is available under <b>Extensions > OpenBay Pro</b>';
