<?php
// Text
$_['text_footer'] = '<a href="http://www.villagedefrance.net">OpenCart OverClocked</a> &copy; 2013-' . date('Y') . ' All Rights Reserved.<br />Version %s';
